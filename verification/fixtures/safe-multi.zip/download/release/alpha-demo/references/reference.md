# Alpha reference
Complete copied resource.
